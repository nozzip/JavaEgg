
package Persona;

import PersonaServicio.PersonaServicio;
import PersonaEntidad.PersonaEntidad;


public class PersonaMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PersonaServicio servicio = new PersonaServicio();

     
        PersonaEntidad persona = servicio.crearPersona();

        
        int edad = servicio.calcularEdad(persona.getFechaNacimiento());

        
        System.out.println("La edad es: " + edad);
    }

}
