package PersonaServicio;

import PersonaEntidad.PersonaEntidad;
import java.util.Date;
import java.util.Scanner;

public class PersonaServicio {

    Scanner leer = new Scanner(System.in);
    //Método crearPersona que pida al usuario Nombre y fecha de nacimiento de la persona a crear. Retornar el objeto Persona creado.

    public PersonaEntidad crearPersona() {
        PersonaEntidad p1 = new PersonaEntidad();
        System.out.println("Ingrese su nombre");
        p1.setNombre(leer.next());

        Date fechaNacimiento = new Date();
        int aa, MM, yyyy;
        System.out.println("Ingrese su fecha de nacimiento:");
        System.out.println(" Dia/Mes/Anio ");

        aa = leer.nextInt();
        MM = leer.nextInt();
        yyyy = leer.nextInt();

        fechaNacimiento.setDate(aa);
        fechaNacimiento.setMonth(MM - 1);
        fechaNacimiento.setYear(yyyy - 1900);

        p1.setFechaNacimiento(fechaNacimiento);

        System.out.println(p1.getNombre());
        System.out.println(p1.getFechaNacimiento());

        return p1;
    }

    public int calcularEdad(Date fechaNacimiento) {
        int edad;
        Date fechaActual = new Date();
        Date cumpleaños = new Date(fechaActual.getYear(), fechaNacimiento.getMonth(), fechaNacimiento.getDate());

        if (cumpleaños.compareTo(fechaActual) < 0) {
            edad = fechaActual.getYear() - fechaNacimiento.getYear();
        } else {
            edad = fechaActual.getYear() - fechaNacimiento.getYear() - 1;
        }

        return edad;
    }
}
