/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidad;

import java.util.ArrayList;

/**
 *
 * esta clase posee los siguientes atributos: Jugadores (conjunto de Jugadores)
 * y Revolver
 */
public class Juego
{

    ArrayList<Jugador> Jugadores;
    RevolverDeAgua revolver;

    public Juego()
    {
    }

    public Juego(ArrayList<Jugador> Jugadores, RevolverDeAgua revolver)
    {
        this.Jugadores = Jugadores;
        this.revolver = revolver;
    }

    public ArrayList<Jugador> getJugadores()
    {
        return Jugadores;
    }

    public void setJugadores(ArrayList<Jugador> Jugadores)
    {
        this.Jugadores = Jugadores;
    }

    public RevolverDeAgua getRevolver()
    {
        return revolver;
    }

    public void setRevolver(RevolverDeAgua revolver)
    {
        this.revolver = revolver;
    }

}
