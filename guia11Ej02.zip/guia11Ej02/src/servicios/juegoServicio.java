/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicios;

import entidad.Juego;
import entidad.Jugador;
import entidad.RevolverDeAgua;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * Métodos: • llenarRevolver(): le pone los valores de posición actual y de
 * posición del agua. Los valores deben ser aleatorios. • mojar(): devuelve true
 * si la posición del agua coincide con la posición actual • siguienteChorro():
 * cambia a la siguiente posición del tambor • toString(): muestra información
 * del revolver (posición actual y donde está el agua)
 */
public class juegoServicio
{

    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    //Metodos revolver
    public void llenarRevolver(RevolverDeAgua revolver)
    {
        revolver.setPosicionTambor((int) Math.random() * 6 + 1);

        revolver.setPosicionAgua((int) Math.random() * 6 + 1);

        System.out.println("El revolver se ha cargado");

    }

    public boolean mojar(RevolverDeAgua revolver)
    {
        boolean mojado = false;

        if (revolver.getPosicionAgua().equals(revolver.getPosicionTambor()))
        {
            mojado = true;
            System.out.println("Te has mojado");

        } else
        {
            System.out.println("Siguiente jugador");
        }

        return mojado;
    }

    public void siguienteChorro(RevolverDeAgua revolver)
    {
        if (revolver.getPosicionTambor().equals(6))
        {
            revolver.setPosicionTambor(1);
            System.out.println("El tambor volvio a la posicion inicial");
        } else
        {

            revolver.setPosicionTambor(revolver.getPosicionTambor() + 1);
            System.out.println("El siguiente tiro esta cargado");
        }

    }

    /*Metodos Jugador:
    el método disparo, recibe el revolver de agua y llama a los métodos de
    mojar() y siguienteChorro() de Revolver. El jugador se apunta, aprieta el gatillo y si el
    revolver tira el agua, el jugador se moja. El atributo mojado pasa a false y el método
    devuelve true, sino false.*/
    public void disparo(RevolverDeAgua revolver, Jugador j)
    {

        if (mojar(revolver))
        {
            j.setMojado(false);
        } else
        {
            siguienteChorro(revolver);

        }

    }

    /*Métodos Juego:
• llenarJuego(ArrayList<Jugador>jugadores, Revolver r): este método recibe los jugadores
y el revolver para guardarlos en los atributos del juego.*/
    public Juego llenarJuego()
    {
        RevolverDeAgua revolver = new RevolverDeAgua();
        ArrayList<Jugador> jugadores = new ArrayList();
        llenarRevolver(revolver);
        System.out.println("Ingrese la cantidad de jugadores");
        int cantidad = leer.nextInt();
        if (cantidad < 2 || cantidad > 6)
        {
            System.out.println("Se ha asignado la cantidad de jugadores a 6");
            cantidad = 6;
        }

        for (int i = 0; i < cantidad; i++)
        {
            Jugador j = new Jugador();
            System.out.println("Ingrese el nombre");
            j.setNombre(leer.next());
            System.out.println("Se generado el ID del jugador");
            j.setId(i + 1);
            jugadores.add(j);

        }

        return new Juego(jugadores, revolver);
    }

    /*
• ronda(): cada ronda consiste en un jugador que se apunta con el revolver de agua y
aprieta el gatillo. Sí el revolver tira el agua el jugador se moja y se termina el juego, sino se
moja, se pasa al siguiente jugador hasta que uno se moje. Si o si alguien se tiene que
mojar. Al final del juego, se debe mostrar que jugador se mojó.*/
    public void ronda(Juego juego)
    {

    }

}
